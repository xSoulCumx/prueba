@extends('layouts.app')

@section('content')
<div class="page-header"><h2> Crud Generator  <small>  Manage your module applications </small> </h2></div>

	{!! Form::open(array('url'=>'product?return='.$return, 'class'=>'form-vertical validated','files' => true )) !!}
	<div class="toolbar-nav">
		<div class="row">
			
			<div class="col-md-6 " >
				<button name="apply" class="tips btn btn-sm btn-default  "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-check"></i> {{ __('core.sb_apply') }} </button>
				<button name="save" class="tips btn btn-sm btn-default"  title="{{ __('core.btn_back') }}" ><i class="fa  fa-paste"></i> {{ __('core.sb_save') }} </button> 
			</div>
			<div class="col-md-6 text-right " >
				<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a> 
			</div>
		</div>
	</div>	


	<div class="p-5">
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
	<div class="row">
	<div class="col-md-4">
						<fieldset><legend> product</legend>
				{!! Form::hidden('productId', $row['productId']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductCode  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productCode' id='productCode' value='{{ $row['productCode'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductLine  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productLine' id='productLine' value='{{ $row['productLine'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductScale  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productScale' id='productScale' value='{{ $row['productScale'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductVendor  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productVendor' id='productVendor' value='{{ $row['productVendor'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> MSRP  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='MSRP' id='MSRP' value='{{ $row['MSRP'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> </fieldset>
			</div>
			
			<div class="col-md-4">
						<fieldset><legend> </legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductName  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productName' id='productName' value='{{ $row['productName'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductDescription  <span class="asterix"> * </span>  </label>									
										  <textarea name='productDescription' rows='5' id='productDescription' class='form-control input-sm '  
				           >{{ $row['productDescription'] }}</textarea> 						
									  </div> </fieldset>
			</div>
			
			<div class="col-md-4">
						<fieldset><legend> </legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> QuantityInStock  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='quantityInStock' id='quantityInStock' value='{{ $row['quantityInStock'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> BuyPrice  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='buyPrice' id='buyPrice' value='{{ $row['buyPrice'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> </fieldset>
			</div>
			
			
	
	</div>

		<input type="hidden" name="action_task" value="save" />
		
		</div>
	</div>		
	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		 		 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("product/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop