

		 {!! Form::open(array('url'=>'product', 'class'=>'form-vertical','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<div class="col-md-4">
						<fieldset><legend> product</legend>
				{!! Form::hidden('productId', $row['productId']) !!}					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductCode  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productCode' id='productCode' value='{{ $row['productCode'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductLine  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productLine' id='productLine' value='{{ $row['productLine'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductScale  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productScale' id='productScale' value='{{ $row['productScale'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductVendor  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productVendor' id='productVendor' value='{{ $row['productVendor'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> MSRP  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='MSRP' id='MSRP' value='{{ $row['MSRP'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> </fieldset>
			</div>
			
			<div class="col-md-4">
						<fieldset><legend> </legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductName  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='productName' id='productName' value='{{ $row['productName'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> ProductDescription  <span class="asterix"> * </span>  </label>									
										  <textarea name='productDescription' rows='5' id='productDescription' class='form-control input-sm '  
				           >{{ $row['productDescription'] }}</textarea> 						
									  </div> </fieldset>
			</div>
			
			<div class="col-md-4">
						<fieldset><legend> </legend>
									
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> QuantityInStock  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='quantityInStock' id='quantityInStock' value='{{ $row['quantityInStock'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> 					
									  <div class="form-group  " >
										<label for="ipt" class=" control-label "> BuyPrice  <span class="asterix"> * </span>  </label>									
										  <input  type='text' name='buyPrice' id='buyPrice' value='{{ $row['buyPrice'] }}' 
						     class='form-control input-sm ' /> 						
									  </div> </fieldset>
			</div>
			
			

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
