

		 {!! Form::open(array('url'=>'demo', 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}

	@if(Session::has('messagetext'))
	  
		   {!! Session::get('messagetext') !!}
	   
	@endif
	<ul class="parsley-error-list">
		@foreach($errors->all() as $error)
			<li>{{ $error }}</li>
		@endforeach
	</ul>		


<ul class="nav nav-tabs form-tab"><li class=" nav-item "><a href="#CustomerInfo" data-toggle="tab" class="nav-link active">Customer Info</a></li>
				<li class=" nav-item "><a href="#Address" data-toggle="tab" class="nav-link ">Address</a></li>
				</ul><div class="tab-content"><div class="tab-pane m-t active" id="CustomerInfo"> 
									
									  <div class="form-group row  " >
										<label for="CustomerNumber" class=" control-label col-md-4 text-left"> CustomerNumber <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='customerNumber' id='customerNumber' value='{{ $row['customerNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="CustomerName" class=" control-label col-md-4 text-left"> CustomerName <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='customerName' id='customerName' value='{{ $row['customerName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="ContactLastName" class=" control-label col-md-4 text-left"> ContactLastName <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='contactLastName' id='contactLastName' value='{{ $row['contactLastName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="ContactFirstName" class=" control-label col-md-4 text-left"> ContactFirstName <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='contactFirstName' id='contactFirstName' value='{{ $row['contactFirstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="SalesRepEmployeeNumber" class=" control-label col-md-4 text-left"> SalesRepEmployeeNumber <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='salesRepEmployeeNumber' id='salesRepEmployeeNumber' value='{{ $row['salesRepEmployeeNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="CreditLimit" class=" control-label col-md-4 text-left"> CreditLimit <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='creditLimit' id='creditLimit' value='{{ $row['creditLimit'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 
			</div>
			
			<div class="tab-pane m-t " id="Address"> 
									
									  <div class="form-group row  " >
										<label for="Phone" class=" control-label col-md-4 text-left"> Phone <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='phone' id='phone' value='{{ $row['phone'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine1" class=" control-label col-md-4 text-left"> AddressLine1 <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='addressLine1' id='addressLine1' value='{{ $row['addressLine1'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="AddressLine2" class=" control-label col-md-4 text-left"> AddressLine2 <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='addressLine2' id='addressLine2' value='{{ $row['addressLine2'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="City" class=" control-label col-md-4 text-left"> City <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='city' id='city' value='{{ $row['city'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="State" class=" control-label col-md-4 text-left"> State <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='state' id='state' value='{{ $row['state'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="PostalCode" class=" control-label col-md-4 text-left"> PostalCode <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='postalCode' id='postalCode' value='{{ $row['postalCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="Country" class=" control-label col-md-4 text-left"> Country <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='country' id='country' value='{{ $row['country'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 
			</div>
			
			

			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-default btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-default btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
				  </div>	  
			
		</div> 
		 <input type="hidden" name="action_task" value="public" />
		 {!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
