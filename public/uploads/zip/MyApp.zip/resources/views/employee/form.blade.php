@extends('layouts.app')

@section('content')
<div class="page-header"><h2> {{ $pageTitle }} <small> {{ $pageNote }} </small> </h2></div>

	{!! Form::open(array('url'=>'employee?return='.$return, 'class'=>'form-horizontal validated','files' => true )) !!}
	<div class="toolbar-nav">
		<div class="row">
			
			<div class="col-md-6 " >
				<button name="apply" class="tips btn btn-sm btn-default  "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-check"></i> {{ __('core.sb_apply') }} </button>
				<button name="save" class="tips btn btn-sm btn-default"  title="{{ __('core.btn_back') }}" ><i class="fa  fa-paste"></i> {{ __('core.sb_save') }} </button> 
			</div>
			<div class="col-md-6 text-right " >
				<a href="{{ url($pageModule.'?return='.$return) }}" class="tips btn btn-sm "  title="{{ __('core.btn_back') }}" ><i class="fa  fa-times"></i></a> 
			</div>
		</div>
	</div>	


	<div class="p-5">
		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>		
		<div class="row">
	<div class="col-md-12">
						<fieldset><legend> Employees</legend>
									
									  <div class="form-group row  " >
										<label for="Photo" class=" control-label col-md-4 text-left"> Photo <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-camera"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="photo" class="upload"   accept="image/x-png,image/gif,image/jpeg"     />
						</div>
						<div class="photo-preview preview-upload">
							{!! SiteHelpers::showUploadedFile( $row["photo"],"/uploads/images/") !!}
						</div>
					 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="EmployeeNumber" class=" control-label col-md-4 text-left"> EmployeeNumber <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='employeeNumber' id='employeeNumber' value='{{ $row['employeeNumber'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="LastName" class=" control-label col-md-4 text-left"> LastName <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='lastName' id='lastName' value='{{ $row['lastName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="FirstName" class=" control-label col-md-4 text-left"> FirstName <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='firstName' id='firstName' value='{{ $row['firstName'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="Extension" class=" control-label col-md-4 text-left"> Extension <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='extension' id='extension' value='{{ $row['extension'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="Email" class=" control-label col-md-4 text-left"> Email <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='email' id='email' value='{{ $row['email'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="OfficeCode" class=" control-label col-md-4 text-left"> OfficeCode <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <input  type='text' name='officeCode' id='officeCode' value='{{ $row['officeCode'] }}' 
						     class='form-control form-control-sm ' /> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="ReportsTo" class=" control-label col-md-4 text-left"> ReportsTo <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  <select name='reportsTo' rows='5' id='reportsTo' class='select2 '   ></select> 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> 					
									  <div class="form-group row  " >
										<label for="JobTitle" class=" control-label col-md-4 text-left"> JobTitle <span class="asterix"> * </span></label>
										<div class="col-md-6">
										  
					<a href="javascript:void(0)" class="btn btn-xs btn-primary pull-right" onclick="addMoreFiles('jobTitle')"><i class="fa fa-plus"></i></a>
					<div class="jobTitleUpl multipleUpl">	
						<div class="fileUpload btn " > 
						    <span>  <i class="fa fa-copy"></i>  </span>
						    <div class="title"> Browse File </div>
						    <input type="file" name="jobTitle[]" class="upload"       />
						</div>		
					</div>
					<ul class="uploadedLists " >
					<?php $cr= 0; 
					$row['jobTitle'] = explode(",",$row['jobTitle']);
					?>
					@foreach($row['jobTitle'] as $files)
						@if(file_exists('./uploads/'.$files) && $files !='')
						<li id="cr-<?php echo $cr;?>" class="">							
							<a href="{{ url('/uploads//'.$files) }}" target="_blank" >
							{!! SiteHelpers::showUploadedFile( $files ,"/uploads/images/",100) !!}
							</a> 
							<span class="pull-right removeMultiFiles" rel="cr-<?php echo $cr;?>" url="/uploads/{{$files}}">
							<i class="fa fa-trash-o  btn btn-xs btn-danger"></i></span>
							<input type="hidden" name="currjobTitle[]" value="{{ $files }}"/>
							<?php ++$cr;?>
						</li>
						@endif
					
					@endforeach
					</ul>
					 
										 </div> 
										 <div class="col-md-2">
										 	
										 </div>
									  </div> </fieldset>
			</div>
			
			
	
		</div>

		<input type="hidden" name="action_task" value="save" />
		
		</div>
	</div>		
	{!! Form::close() !!}
		 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		
		
		$("#reportsTo").jCombo("{!! url('employee/comboselect?filter=employees:employeeNumber:lastName|firstName') !!}",
		{  selected_value : '{{ $row["reportsTo"] }}' });
		 		 

		$('.removeMultiFiles').on('click',function(){
			var removeUrl = '{{ url("employee/removefiles?file=")}}'+$(this).attr('url');
			$(this).parent().remove();
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop